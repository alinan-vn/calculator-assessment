# Calculator Assessment for HCL

Simple calculator made in Java that takes in two integer values and an operation (Addition, Subtraction, Multiplication, Division) and returns a float answer.

List of requirements (fulfilled): Core Java concepts: Variables, data types, operators, type casting, control statements, class, objects, access specifiers, and core keywords like final, this, and static